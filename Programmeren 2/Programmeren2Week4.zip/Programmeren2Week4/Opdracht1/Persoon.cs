﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Opdracht1
{
    class Persoon
    {
        public string naam;
        public string woonplaats;
        public int leeftijd;
    }
}
